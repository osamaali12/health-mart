<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M47,48c8.837,0,16-7.163,16-16s-7.163-16-16-16H17
	C8.163,16,1,23.163,1,32s7.163,16,16,16H47z"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="17" cy="32" r="12"/>
</svg>
