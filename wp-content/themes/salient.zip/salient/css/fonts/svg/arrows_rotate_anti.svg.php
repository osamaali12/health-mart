<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M31,1C23.322,1,15.646,3.929,9.788,9.787
		C-0.91,20.484-1.841,37.248,6.997,49l6.001,6.002"/>
</g>
<g>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M33,63c7.678,0,15.354-2.929,21.212-8.787
		C64.91,43.516,65.841,26.752,57.003,15l-6.001-6.002"/>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="13,44 13,55 2,55 
	"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="51,20 51,9 62,9 
	"/>
</svg>
