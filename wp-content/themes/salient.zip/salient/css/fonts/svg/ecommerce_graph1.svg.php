<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M54.999,36.001C55,50.913,42.912,63,28,62.999
	C13.087,63,1,50.912,1.001,36C1,21.088,13.088,9,28,9.001V36L54.999,36.001z"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M63,28C63.001,13.087,50.914,0.998,36.001,1v27H63z"
	/>
</svg>
